<link rel="stylesheet" href="../Styles.css">

<svg viewBox="0 0 400 400">
  <g id="record">
  <circle r="200" cx="200" cy="200" />
  <circle class="line" r="180" cx="200" cy="200" />
  <circle class="line" r="160" cx="200" cy="200" />
  <circle class="line" r="140" cx="200" cy="200" />
  <circle id="label" cx="200" cy="200" r="65" />
  <text y="180" x="145" font-family="Lucida Handwriting">Everything</text>  
  <text y="230" x="145" font-family="Lucida Handwriting">Saxophones</text>    
  <circle id="dot" cx="200" cy="200" r="6" />
  </g>
</svg>

<a href="index.php"     title="Back to Home Page"><button               id="B1" type="button">Home page</button></a>
<a href="Inventor.php"  title="The one who invented saxophones"><button id="B2" type="button">Saxophones' Inventor</button></a>
<a href="SaxFamily.php" title="Saxophones' Family"><button              id="B3" type="button">Saxophones' Family</button></a>
<a href="Jazz.php"      title="Saxophones' influence on Jazz"><button   id="B4" type="button">Saxophone and Jazz</button></a>

<marquee width="100%" direction="left">
&#119073 Everything Saxophone - Saxophone's intricate history - The many types of Saxophones - Want to play the sax masterfully? Sign up Now! Contact : 0***-*18*9-7788 (Mr.Joshua Highmore) for more information &#119046
</marquee>

<a href="https://avonschoolofmusic.org/"><img id="logo" src="../Images/Logo2.png" height="190px" width="200px" alt=""></a>