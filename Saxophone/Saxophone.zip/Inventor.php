<html>
 <head>
<?php include("Navigation bar/recordDisk.php"); ?>

 </head> 
  
<body>
  <h1 class="titles">Antoine Joseph Sax</h1>
  <h3 class=" titles">"Little Sax, the ghost"</h3>
  <div>
    <p class="decorLines"></p>
    <div class="ASax">
    <img src="../Images/Adolphe_Sax.jpg" height="350px" width="200px" alt=""/>
    <img src="../Images/Statue.png" height="350px" width="320px" alt="">
    <img src="../Images/Sitting.jpg" height="350px" width="200px" >
    </div>
    <p class="decorLines"></p>
    <p>Antoine-Joseph Sax was born on 6 November 1814 in Dinant, in what is now Belgium, to Charles-Joseph Sax and his wife Marie-Joseph (Masson). While his given name was Antoine-Joseph, he was referred to as Adolphe from childhood. His father and mother were instrument designers themselves, who made several changes to the design of the French horn. Adolphe began to make his own instruments at an early age, entering two of his flutes and a clarinet into a competition at the age of 15. He subsequently studied performance on those two instruments as well as voice at the Royal Conservatory of Brussels.</p>
    <p>Through his life, he faces many Many brushes with death. His mother once said that "he's a child condemned to misfortune; he won't live". Even neighbors called him "little Sax, the ghost". His various misfortunes includes but not limited to:</p>
    <p>At age 2, he fell out of the window of a two-story building and fractured his skull.</p>
    <p>When he was 6 years old, he accidentally drank acid.</p>
    <p>At about age 9 he fell down a flight of stairs, toppled onto a burning stove.</p>
    <p>When he was 11 years old, he contracted measles and was in a coma for 9 days.</p>
    <p>At age 14, he broke his arm and got caught in a carriage door.</p>
    <p>When he was 19 years old, a brick fell right on his head.</p>
    <p>He is on record to also have swallowed a needle.</p>
    <p>When he was 23 years old, he almost killed himself by drinking tainted wine.</p>
    <p>His misadventures doesn't stop there, gunpowder burns and lip cancer,..</p>
    <p>And at 29, Adolphe Sax invented <strong>the saxophone</strong>.</p>
    <p>In the end, he managed to live for 79 years.</p>
    <p>Sax died in poverty after being declared bankrupt three times.</p>
    
    <p class="decorLines"></p>
  </div>
</body>
  
</html>
